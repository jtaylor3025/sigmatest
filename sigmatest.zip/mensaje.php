<!--=====MENSAJE=====-->
<section>
    <!-- Modal -->
    <div id="myMsgModal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
        <div id="MensajePersonal" class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content" style="background-color: #f5f5f5;">
                <div class="modal-header">
                    <h4 id="tituloMsg" class="modal-title text-center">AQUÍ VA EL TÍTULO</h4>
                </div>
                <div id="contenidoMsg" class="modal-body row justify-content-center">
                    AQUÍ VA EL CONTENIDO
                </div>
                <div id="botonesMsg" class="modal-footer">
                    AQUÍ VAN LOS BOTONES
                </div>
            </div>

        </div>
    </div>
</section>
<!--=====FIN MENSAJE=====-->
<?php
//myMsgModal: ID DEL MODAL de mensajes
//tituloMsg: Titulo del mensaje
//contenidoMsg: Contenido que llevará el mensaje
//botonesMsg van el o los botones que requiera el mensaje
?>