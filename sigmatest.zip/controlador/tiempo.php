<?php
function tiempo()
{
    $zonaHoraria = 'America/Bogota';
    date_default_timezone_set($zonaHoraria);
    $ahora = date('Y-m-d H:i:s');
    return $ahora;
}
