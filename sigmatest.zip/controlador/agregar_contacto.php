<?php
session_start();
require 'tiempo.php';
require_once '../modelo/Conexion.php';
$con = new Conexion();

$name = $_POST['nombre'];
$mail = $_POST['mail'];
$state = $_POST['departamento'];
$city = $_POST['ciudad'];
$create_at = tiempo();
$update_at = tiempo();


if (!empty($name) && !empty($mail) && !empty($state) && !empty($city)) {
    $dml = "INSERT INTO contacts VALUES(null, '$name', '$mail', '$state', '$city', '$create_at', '$update_at')";
    $msg = $con->ejecutarDML($dml);
    if ($msg == 'OK') {
        echo '<META HTTP-EQUIV="REFRESH" CONTENT="0;URL=../index.php?txt=agregado">';
    } else {
        echo '<META HTTP-EQUIV="REFRESH" CONTENT="0;URL=../index.php?txt=errmysql">';
    }
} else {
    echo '<META HTTP-EQUIV="REFRESH" CONTENT="0;URL=../index.php?txt=faltadato">';
}
