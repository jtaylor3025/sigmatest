<?php
session_start();
@$mensaje = $_GET['txt'];
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <?php
    include('includes/head.php');
    ?>
</head>

<body>
    <?php
    include 'mensaje.php';
    if ($mensaje == 'agregado') {
    ?>
        <script>
            $(document).ready(function() {
                $('#tituloMsg').html('Agregado');
                $('#contenidoMsg').html('El contacto ha sido correctamente agregado');
                var ruta = ".";
                $('#botonesMsg').html('<button class="btn btn-success" onclick="redireccionar(\'' + ruta + '\')" data-dismiss="modal">Aceptar</button>');
                $('#myMsgModal').modal("show");
            });
        </script>
    <?php
    } else if ($mensaje == 'errmysql') {
    ?>
        <script>
            $(document).ready(function() {
                $('#tituloMsg').html('Error MySQL');
                $('#contenidoMsg').html('Ha ocurrido un error de sintaxis en la Base de datos o no se ha logrado conectar a la Base de datos');
                var ruta = ".";
                $('#botonesMsg').html('<button class="btn btn-success" onclick="redireccionar(\'' + ruta + '\')" data-dismiss="modal">Aceptar</button>');
                $('#myMsgModal').modal("show");
            });
        </script>
    <?php
    } else if ($mensaje == 'faltadato') {
    ?>
        <script>
            $(document).ready(function() {
                $('#tituloMsg').html('Falta dato');
                $('#contenidoMsg').html('Falta un dato para poder ser agregado, intentelo de nuevo y verifique que ha llenado todos los datos correctamente');
                var ruta = ".";
                $('#botonesMsg').html('<button class="btn btn-success" onclick="redireccionar(\'' + ruta + '\')" data-dismiss="modal">Aceptar</button>');
                $('#myMsgModal').modal("show");
            });
        </script>
    <?php
    }
    ?>
    <header>
        <?php
        include('includes/header.php');
        ?>
    </header>
    <div class="row">
        <div class="col-12 mt-2 align-content-center text-center">
            <h1 class="mt-2 mb-2">Prueba de desarrollo Sigma</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-3 mt-2"></div>
        <div class="col-6 mt-2 text-center" style="color: #666666; font-weight: bold;">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-lg-2 col-md-12 mt-2"></div>
        <div class="col-12 col-lg-4 col-md-6 mt-2 p-3">
            <div class="m-2 text-center">
                <img class="img-der-form" src="img/sigma-image.png" />
            </div>
        </div>
        <div class="col-12 col-lg-4 col-md-6 mt-2 text-center">
            <div class="form-contact col-12">
                <form method="post" action="controlador/agregar_contacto.php" onsubmit="return validarEmail('mail')">
                    <div>
                        <label for="departamento">Departamento*</label></br>
                        <select id="departamento" name="departamento" required>
                            <option value="">Seleccione...</option>
                        </select>
                    </div>
                    <div>
                        <label for="ciudad">Ciudad*</label></br>
                        <select id="ciudad" name="ciudad" disabled required>
                            <option value="">Seleccione...</option>
                        </select>
                    </div>
                    <div>
                        <label for="nombre">Nombre*</label></br>
                        <input type="text" id="nombre" name="nombre" placeholder="Pepito de Jesús" required />
                    </div>
                    <div>
                        <label for="mail">Correo*</label></br>
                        <input type="mail" id="mail" name="mail" placeholder="pepitodejesus@gmail.com" required />
                    </div>
                    <div style="text-align: center;">
                        <button type="submit" class="btn-enviar">Enviar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
<script src="js/validar.js"></script>
</html>