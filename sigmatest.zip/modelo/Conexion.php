<?php

class Conexion {

    private $_servidor;
    private $_usuario;
    private $_clave;
    protected $_bd;
    protected $_conexion;

    public function __construct() {

        $this->_servidor = "178.128.146.252";
        $this->_usuario = "admin_sigmauser";
        $this->_clave = "pfaDKIJyPF";
        $this->_bd = "admin_sigmatest";
        if (!isset($this->_conexion)) {
            $this->_conexion = (mysqli_connect($this->_servidor, $this->_usuario, $this->_clave, $this->_bd)) or die(mysqli_connect_errno());
            mysqli_set_charset($this->_conexion, 'utf8');
        } else {
            echo "<script>alert('no se pudo realizar la conexión por problemas con el servidor');</script>";
        }
    }

    public function consultarDML($dml) {
        $resultado = mysqli_query($this->_conexion, $dml);
        $i = 0;
        while ($consulta = mysqli_fetch_assoc($resultado)) {
            $lista[$i] = $consulta;
            $i++;
        }
        return $lista;
    }

    public function ejecutarDML($dml) {
        $resultado = mysqli_query($this->_conexion, $dml);
        $msg = "OK";
        if (!$resultado) {
            $err = 'MySQL Error: ' . mysqli_error($this->_conexion);
            $msg = "No se pudo ejecutar el proceso solicitado $err";
        }
        return $msg;
    }

    public function contarFilas($dml) {
        $resultado = mysqli_query($this->_conexion, $dml);
        $numFilas = mysqli_num_rows($resultado);
        return $numFilas;
    }

    function __destruct() {
        @mysqli_close($this->_conexion);
    }

}
