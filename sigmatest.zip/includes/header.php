<div id="logo" class="row text-center">
    <div class="col-12 mt-2 align-content-center text-center">
        <img src="img/sigma-logo.png">
    </div>
</div>