//
var depto = [];
var url = 'https://sigma-studios.s3-us-west-2.amazonaws.com/test/colombia.json';
$.getJSON(url, function(data) {
        $.each(data, function(index, d) {
            depto.push(index);
        });
        var j = 1;
        for (var i = 0; i < depto.length; i++) {
            $('#departamento').append('<option value="' + depto[i] + '">' + depto[i] + '</option>');
            j++;
        }
        $("#departamento").change(function() {
            var mpio = [];
            $('#ciudad').removeAttr('disabled');
            if ($("#departamento").val() == "") {
                $('#ciudad').attr('disabled', true);
            }
            $("#ciudad").empty();
            $('#ciudad').append('<option value="">Seleccione...</option>');
            $.each(data, function(index, d) {
                if (index == $('#departamento').val()) {
                    var mpioJson = d;
                    for (var i = 0; i < mpioJson.length; i++) {
                        mpio.push(mpioJson[i]);
                    }
                }
            });
            var j = 1;
            for (var i = 0; i < mpio.length; i++) {
                $('#ciudad').append('<option value="' + mpio[i] + '">' + mpio[i] + '</option>');
                j++;
            }
        });

    })
    .fail(function() {
        url = 'wsjson/colombia.json';
        $.getJSON(url, function(data) {
            $.each(data, function(index, d) {
                depto.push(index);
            });
            var j = 1;
            for (var i = 0; i < depto.length; i++) {
                $('#departamento').append('<option value="' + depto[i] + '">' + depto[i] + '</option>');
                j++;
            }
            $("#departamento").change(function() {
                var mpio = [];
                $('#ciudad').removeAttr('disabled');
                if ($("#departamento").val() == "") {
                    $('#ciudad').attr('disabled', true);
                }
                $("#ciudad").empty();
                $('#ciudad').append('<option value="">Seleccione...</option>');
                $.each(data, function(index, d) {
                    if (index == $('#departamento').val()) {
                        var mpioJson = d;
                        for (var i = 0; i < mpioJson.length; i++) {
                            mpio.push(mpioJson[i]);
                        }
                    }
                });
                var j = 1;
                for (var i = 0; i < mpio.length; i++) {
                    $('#ciudad').append('<option value="' + mpio[i] + '">' + mpio[i] + '</option>');
                    j++;
                }
            });

        });
    });