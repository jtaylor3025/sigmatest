function vacio(campos) {
    var boleano = true;
    var array_campos = campos.split(',');
    for (var i = 0; i < array_campos.length; i++) {
        var campo = array_campos[i];
        if (campo != '' && campo != "" && campo != 0 && campo != 'undefined' && campo != null) {
            boleano = false;
            break;
        }
    }
    return boleano;
}

function validarEmail(campo) {
    var valor = $('#' + campo).val();
    var valida = true;
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (regex.test(valor)) {
        valida = true;
    } else {
        valida = false;
        $('#tituloMsg').html('E-mail incorrecto');
        $('#contenidoMsg').html('Ha digitado un e-mail incorrecto');
        //var ruta = "formulario.php";
        //$('#botonesMsg').html('<button class="btn btn-success" onclick="redireccionar(\'' + ruta + '\')" data-dismiss="modal">Aceptar</button>');
        $('#botonesMsg').html('<button class="btn btn-success" data-dismiss="modal">Aceptar</button>');
        $('#myMsgModal').modal("show");
    }
    return valida;
}

function redireccionar(ruta) {
    window.location = ruta;
}